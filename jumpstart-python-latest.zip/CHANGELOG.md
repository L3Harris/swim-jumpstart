# JumpStart Python Changelog

## 1.0.1

- Revise connection sequence

## 1.0.0

- Initial Release

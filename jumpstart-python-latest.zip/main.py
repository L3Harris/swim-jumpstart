import os
from solace.messaging.messaging_service import MessagingService
from solace.messaging.resources.queue import Queue
from solace.messaging.receiver.message_receiver import MessageHandler, InboundMessage
from solace.messaging.config.transport_security_strategy import TLS
from solace.messaging.config.retry_strategy import RetryStrategy
from meter import Meter
from set_interval import SetInterval
from enum import Enum

import shutil
import threading
import argparse

class OutputType(Enum):
    none = 'none'
    length = 'length'
    console = 'console'
    directory = 'directory'
    file = 'file'
    def __str__(self):
        return self.value

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-u", "--username", type=str, default=os.getenv("JUMP_USER"))
    parser.add_argument("-p", "--password", type=str, default=os.getenv("JUMP_PASS"))
    parser.add_argument("-H", "--host", type=str, default=os.getenv("JUMP_HOST"))
    parser.add_argument("-v", "--vpn", type=str, default=os.getenv("JUMP_VPN"))
    parser.add_argument("-q", "--queue", type=str, default=os.getenv("JUMP_QUEUE"))
    parser.add_argument("-r", "--retry", type=int, default=os.getenv("JUMP_RETRY", 3000))
    parser.add_argument("-c", "--cert", type=str, default=os.getenv("JUMP_CERT", "./solace-ca"))
    parser.add_argument("-us", "--unsafe", type=bool, default=os.getenv("JUMP_UNSAFE", False))
    parser.add_argument("-o", "--output", type=OutputType, default=os.getenv("JUMP_OUTPUT", "none"))
    args = parser.parse_args()

    if ([args.host, args.username, args.password, args.host, args.vpn, args.queue].count(None) > 0):
        raise ValueError('Did not find all arguments in CLI command or environment variables')
    return args

def build_service(args):
    if (args.unsafe):
        security_strategy = TLS.create().without_certificate_validation()
        print("Certificate will not be validated")
    else:
        security_strategy = TLS.create().with_certificate_validation(True, False, args.cert)
        print(f"Certificate from {args.cert} will be validated")

    retry_strategy = RetryStrategy.forever_retry(retry_interval=args.retry)
    service = (
        MessagingService.builder()
        .from_properties(
            {
                "solace.messaging.transport.host": args.host,
                "solace.messaging.service.vpn-name": args.vpn,
                "solace.messaging.authentication.scheme.basic.username": args.username,
                "solace.messaging.authentication.scheme.basic.password": args.password,
            }
        )
        .with_connection_retry_strategy(retry_strategy)
        .with_reconnection_retry_strategy(retry_strategy)
        .with_transport_security_strategy(security_strategy)
        .build()
    )
    return service

class MessageHandlerImpl(MessageHandler):
    def __init__(self, args, receiver):
        self._message_count = 0
        self._args = args
        self._receiver = receiver
        self._meter = Meter()
        # Start with a clean slate each time
        dir = "./log/"
        if os.path.exists(dir):
            shutil.rmtree(dir)
        os.makedirs(dir)
        SetInterval(1.0, self.log_rates)

    def log_rates(self):
        print(self._meter.get_rates())

    def on_message(self, message: InboundMessage):
        try:
            topic = message.get_destination_name()
            payload_str = message.get_payload_as_string()
            self._meter.mark()
            self._message_count += 1
            match self._args.output:
                case OutputType.none:
                    # Only periodic rate logging
                    pass
                case OutputType.length:
                    print(f"[{self._message_count}] Received [{topic}] with length: {len(payload_str)}")
                case OutputType.console:
                    print(payload_str)
                case OutputType.directory:
                    path = f"./log/{self._message_count}.xml"
                    with open(path, "w") as f:
                        f.write(payload_str)
                    print(f"[{self._message_count}] Wrote to {path}")
                case OutputType.file:
                    path = "./log/messages.log"
                    with open(path, "a") as f:
                        f.write(f"{payload_str}\n")
                    print(f"[{self._message_count}] Wrote to {path}")

            self._receiver.ack(message)
        except Exception as e:
            print(f"Error processing message: {e}")

def main():
    args = get_args()
    service = build_service(args)
    queue = Queue.durable_exclusive_queue(args.queue)
    receiver = service.create_persistent_message_receiver_builder().build(queue)

    print("Connecting...")
    service.connect()
    print("Connected")

    receiver.start()
    receiver.receive_async(MessageHandlerImpl(args, receiver))

    print("Listening for messages...")
    threading.Event().wait()

if __name__ == "__main__":
    main()
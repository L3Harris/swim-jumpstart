# Python JumpStart

## Setup

### Libraries

We recommend using a virtual installation environment, such as [venv](https://docs.python.org/3/library/venv.html) (demonstrated below).

```bash
# Bash on Linux
python3 -m venv .venv
source .venv/bin/activate
pip install solace
pip install solace-pubsubplus
```

```ps1
# Powershell on Windows
python3 -m venv .venv
.venv\Scripts\Activate.ps1
pip install solace
pip install solace-pubsubplus
```

### Certificate Validation

Solace expects a certificate directory (unless you run with `-us True` or `JUMP_UNSAFE=True`).

You can create it with the command below:

```bash
# Bash on Linux
mkdir -p ./solace-ca
cp /etc/ssl/certs/ISRG_Root_X1.pem ./solace-ca/
c_rehash ./solace-ca
```

```ps1
# Powershell on Windows
mkdir solace-ca
Invoke-WebRequest -Uri https://letsencrypt.org/certs/isrgrootx1.pem -OutFile "solace-ca/isrgrootx1.pem"
```

## Execution

Values for a given subscription can be found on the subscription's JumpStart tab.

```bash
python3 main.py \
-H "tcps://CHANGEME:55443" \
-q "CHANGEME" \
-v "CHANGEME" \
-u "CHANGEME" \
-p "CHANGEME"
```

### Configuration

You can run with CLI parameters and/or environment variables with priority order `cli -> env -> default`.

| Parameter | Environment Variable | Description                                           | Default         |
|:---------:|:---------------------|:------------------------------------------------------|:---------------:|
| `-h`      |                      | ignore other arguments and show CLI help menu         | -               |
| `-H`      | `JUMP_HOST`          | the host provider URL                                 | -               |
| `-q`      | `JUMP_QUEUE`         | the queue name                                        | -               |
| `-v`      | `JUMP_VPN`           | the vpn to be used                                    | -               |
| `-u`      | `JUMP_USER`          | your username                                         | -               |
| `-p`      | `JUMP_PASS`          | your *subscription* password (not your SWIM password) | -               |
| `-c`      | `JUMP_CERT`          | the hashed certificates directory (see below)         | `"./solace-ca"` |
| `-us`     | `JUMP_UNSAFE`        | do not validate the cert in `-c`                      | `False`         |
| `-r`      | `JUMP_RETRY`         | reconnect interval in ms                              | `3000`          |
| `-o`      | `JUMP_OUTPUT`        | where to output the message (options below)           | `none`          |

#### Output Types

- `none`: do not output the message contents anywhere
- `console`: print the message contents to standard out
- `file`: append the message's contents to `log/messages.log`
- `directory`: for each message, create an indexed file at `log/{i}.xml`

### Debugging with VS Code

Create a `.vscode/launch.json` file with the following:

```jsonc
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
        {
            "type": "debugpy",
            "request": "launch",
            "name": "Python JumpStart",
            "program": "${workspaceFolder}/main.py",
            "env": {
                "JUMP_PASS": "CHANGEME",
                "JUMP_USER": "CHANGEME",
                "JUMP_VPN": "CHANGEME",
                "JUMP_HOST": "CHANGEME",
                "JUMP_QUEUE": "CHANGEME"
            }
        }
    ]
}
```

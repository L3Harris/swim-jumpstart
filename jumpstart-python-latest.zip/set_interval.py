from threading import Event, Thread

class SetInterval:
    def __init__(self, interval, action, *args, **kwargs):
        self.interval = interval
        self.action = action
        self.args = args
        self.kwargs = kwargs
        self.stop_event = Event()
        
        # Start the background thread immediately
        self.thread = Thread(target=self._run)
        self.thread.daemon = True  # Allows the program to exit even if thread is running
        self.thread.start()

    def _run(self):
        # wait() returns True if stop_event.set() is called, breaking the loop
        while not self.stop_event.wait(self.interval):
            self.action(*self.args, **self.kwargs)

    def cancel(self):
        """Equivalent to clearInterval()"""
        self.stop_event.set()
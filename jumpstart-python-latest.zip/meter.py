import math
import threading
import time

class EWMA:
    def __init__(self, interval_seconds: float, window_seconds: float):
        self.interval_seconds = interval_seconds
        self.window_seconds = window_seconds

        self._rate = 0.0
        self._count = 0
        self._initialized = False

        # Standard EWMA alpha:
        # 1 - exp(-interval / window)
        self._alpha = 1.0 - math.exp(
            -interval_seconds / window_seconds
        )

    def update(self, count: int = 1):
        self._count += count

    def tick(self):
        instant_rate = self._count / self.interval_seconds
        self._count = 0

        if self._initialized:
            self._rate += self._alpha * (
                instant_rate - self._rate
            )
        else:
            self._rate = instant_rate
            self._initialized = True

    @property
    def rate(self) -> float:
        return self._rate

class Meter:
    """
    A Dropwizard Metrics-style Meter.

    Tracks:
      - total event count
      - mean rate since creation
      - 1-minute EWMA rate
      - 5-minute EWMA rate
      - 15-minute EWMA rate
    """

    TICK_INTERVAL_SECONDS = 5.0

    def __init__(self):
        self._count = 0
        self._lock = threading.Lock()
        self._start_time = time.monotonic()

        self._m1 = EWMA(
            self.TICK_INTERVAL_SECONDS,
            60.0,
        )

        self._m5 = EWMA(
            self.TICK_INTERVAL_SECONDS,
            5 * 60.0,
        )

        self._m15 = EWMA(
            self.TICK_INTERVAL_SECONDS,
            15 * 60.0,
        )

        self._stop_event = threading.Event()

        self._ticker = threading.Thread(
            target=self._run_ticker,
            daemon=True,
        )

        self._ticker.start()

    def mark(self, count: int = 1):
        if count < 0:
            raise ValueError("count must be >= 0")

        with self._lock:
            self._count += count

        self._m1.update(count)
        self._m5.update(count)
        self._m15.update(count)

    def get_count(self) -> int:
        with self._lock:
            return self._count

    def get_mean_rate(self) -> float:
        elapsed = time.monotonic() - self._start_time

        if elapsed <= 0:
            return 0.0

        return self.get_count() / elapsed

    def get_one_minute_rate(self) -> float:
        return self._m1.rate

    def get_five_minute_rate(self) -> float:
        return self._m5.rate

    def get_fifteen_minute_rate(self) -> float:
        return self._m15.rate

    def get_rates(self) -> dict:
        return {
            "count": self.get_count(),
            "meanRate": self.get_mean_rate(),
            "oneMinuteRate": self.get_one_minute_rate(),
            "fiveMinuteRate": self.get_five_minute_rate(),
            "fifteenMinuteRate": self.get_fifteen_minute_rate(),
        }

    def stop(self):
        self._stop_event.set()
        self._ticker.join(timeout=1.0)

    def _run_ticker(self):
        while not self._stop_event.wait(
            self.TICK_INTERVAL_SECONDS
        ):
            self._m1.tick()
            self._m5.tick()
            self._m15.tick()

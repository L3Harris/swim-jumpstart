# Node JS JumpStart

This is a simple SMF Consumer that allows for testing the connection to SCDS.

It is not intended to be used for a real world application.

The JumpStart allows you to log the message rate metrics and/or messages to the console.

## Setup

> **NOTE**: We recommend [pnpm](https://pnpm.io/installation) over `npm` for speed and security.

Run the below command from a terminal for this directory.

### Linux

```bash
# Bash on Linux
pnpm ci
```

### Windows

```ps1
# Powershell on Windows
pnpm ci
```

## Execution

Values for a given subscription can be found on the subscription's JumpStart tab.

```bash
node main.js \
-h "tcps://CHANGEME:55443" \
-q "CHANGEME" \
-v "CHANGEME" \
-u "CHANGEME" \
-p "CHANGEME"
-m
```

### Configuration

set the following environment variables or specify them in the command

| Parameter  | Environment Variable | Description                                                 |
|:-----------|:---------------------|:------------------------------------------------------------|
| `-h`       | `JUMP_HOST`          | the host provider URL                                       |
| `-q`       | `JUMP_QUEUE`         | the queue name                                              |
| `-v`       | `JUMP_VPN`           | the vpn to be used                                          |
| `-u`       | `JUMP_USER`          | your username                                               |
| `-p`       | `JUMP_PASS`          | your *subscription* password (not your SWIM password)       |
| `-o`       | `JUMP_OUTPUT`        | the output type, default `none` (see below for options)     |
| `-m`       | `JUMP_META`          | includes the header metadata in the output, default `false` |

#### Output Types

- `none`: do not output the message contents anywhere but do print periodic message rate reports to standard output
- `length`: print message reception and length to standard output
- `console`: print the message contents to standard output
- `file`: append the message's contents to `log/messages.log`
- `directory`: create an indexed file at `log/{i}.xml`

### Debugging with VS Code

Create a `.vscode/launch.json` file with the following:

```jsonc
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
        {
            "type": "node",
            "request": "launch",
            "name": "NodeJS JumpStart",
            "skipFiles": [
                "<node_internals>/**"
            ],
            "program": "${workspaceFolder}/main.js",
            "env": {
                "JUMP_PASS": "CHANGEME",
                "JUMP_USER": "CHANGEME",
                "JUMP_VPN": "CHANGEME",
                "JUMP_HOST": "CHANGEME",
                "JUMP_QUEUE": "CHANGEME"
            }
        }
    ]
}
```

import solace from 'solclientjs';
import commandLineArgs from 'command-line-args';
import Meter from './meter.js';
import { mkdirSync, writeFileSync, appendFileSync, rmSync } from 'node:fs';

/**
 * @typedef {'none'|'length'|'console'|'file'|'directory'} OutputType
 * @typedef {{
 *  username: string,
 *  password: string,
 *  host: string,
 *  vpn: string,
 *  queue: string,
 *  output: OutputType
 * }} Arguments
 * */
const getArgs = () => {
    /** @type {Arguments} */
    const args = commandLineArgs([
        { name: 'username', alias: 'u', type: String, defaultValue: process.env.JUMP_USER },
        { name: 'password', alias: 'p', type: String, defaultValue: process.env.JUMP_PASS },
        { name: 'host', alias: 'h', type: String, defaultValue: process.env.JUMP_HOST },
        { name: 'vpn', alias: 'v', type: String, defaultValue: process.env.JUMP_VPN },
        { name: 'queue', alias: 'q', type: String, defaultValue: process.env.JUMP_QUEUE },
        { name: 'output', alias: 'o', type: String, defaultValue: process.env.JUMP_OUTPUT || 'none' },
        { name: 'headers', alias: 'm', type: Boolean, defaultValue: process.env.JUMP_META ?? false },
    ]);

    // Validate args
    if (!args.username || !args.password || !args.host || !args.vpn || !args.queue)
        throw new Error('please provide all required arguments via CLI or environment variables');
    const outputTypes = ['none', 'length', 'console', 'file', 'directory'];
    if (!outputTypes.includes(args.output))
        throw new Error('output type must be in ' + JSON.stringify(outputTypes));

    return args;
};

/**
 * Creates a session from the provided arguments
 * @param {Arguments} args 
 * @returns {{ session: solace.Session, shutdown: (signal: string) => void }}
 */
const buildSession = (args) => {
    const session = solace.SolclientFactory.createSession({
        url: args.host,
        vpnName: args.vpn,
        userName: args.username,
        password: args.password,
    });

    // Session event handlers
    let messageCount = 0;
    let consumer;
    let rateReporter;
    let shuttingDown = false;
    const meter = new Meter();
    session.on(solace.SessionEventCode.UP_NOTICE, () => {
        console.log("Connected.");

        if (shuttingDown) {
            return;
        }

        const queue = solace.SolclientFactory.createDurableQueueDestination(args.queue);

        consumer = session.createMessageConsumer({
            queueDescriptor: {
                name: queue.getName(),
                type: solace.QueueType.QUEUE
            },
            acknowledgeMode: solace.MessageConsumerAcknowledgeMode.CLIENT
        });

        if (args.output !== 'console') {
            rateReporter = setInterval(() => console.log(meter.getRates()), 1000);
        }

        consumer.on(solace.MessageConsumerEventName.UP, () => {
            console.log(`Bound to queue`);
        });

        consumer.on(solace.MessageConsumerEventName.CONNECT_FAILED_ERROR, (e) => {
            console.error("Consumer failed:", e);
        });

        consumer.on(solace.MessageConsumerEventName.DOWN, () => {
            console.log("Consumer disconnected");
        });

        consumer.on(solace.MessageConsumerEventName.MESSAGE, (message) => {
            try {
                meter.mark();
                const xmlDecoded = message.getXmlContentDecoded();
                const messageId = message.getApplicationMessageId();
                const destination = message.getDestination()?.getName();
                const props = message.getUserPropertyMap();
                const headers = Object.keys(props._map).map(k => `${k}: ${props._map[k]._value}`);
                messageCount++
                if (xmlDecoded) {
                    switch (args.output) {
                        case 'none': {
                            // Only periodic rate logging
                            break;
                        }
                        case 'length': {
                            console.log(`[${messageCount}] Received [${destination}] with ${Object.keys(props._map).length} headers and size of ${xmlDecoded.length}`);
                            break;
                        }
                        case 'console': {
                            if (args.headers) console.log(headers);
                            console.log(xmlDecoded);
                            break;
                        }
                        case 'directory': {
                            let path = '';
                            if (args.headers) {
                                path = `./log/${messageCount}.txt`;
                                writeFileSync(path, `${headers.join(', ')}\n${xmlDecoded}`);
                            } else {
                                path = `./log/${messageCount}.xml`;
                            writeFileSync(path, xmlDecoded);
                            }
                            console.log(`[${messageCount}] Wrote to ${path}`);
                            break;
                        }
                        case 'file': {
                            const path = `./log/messages.log`;
                            if (args.headers) appendFileSync(path, headers.join(', ') + '\n');
                            appendFileSync(path, xmlDecoded + '\n');
                            console.log(`[${messageCount}] Appended to ${path}`);
                            break;
                        }
                        default: throw new Error('unrecognized output type: ' + args.output);
                    }
                }

                // Tell the broker we're done with the message
                message.acknowledge();
            } catch (err) {
                console.error(err);
            }
        });

        consumer.connect();
    });

    session.on(solace.SessionEventCode.CONNECT_FAILED_ERROR, (e) => {
        console.error("Connection failed:", e);
    });

    session.on(solace.SessionEventCode.DISCONNECTED, () => {
        console.log("Disconnected");
    });

    const shutdown = (signal) => {
        if (shuttingDown) {
            return;
        }

        shuttingDown = true;
        console.log(`Received ${signal}; shutting down...`);

        if (rateReporter) {
            clearInterval(rateReporter);
            rateReporter = undefined;
        }
        meter.stop();

        // Stop message delivery before closing the session. Any message that
        // has not been acknowledged remains available for redelivery.
        try {
            consumer?.stop();
        } catch (_) {}
        try {
            consumer?.disconnect();
        } catch (_) {}
        try {
            session.disconnect();
        } catch (_) {}

        // Do not force process.exit(): this gives the Solace client time to
        // complete disconnect processing and lets Node exit when handles close.
    };

    return { session, shutdown };
};

const main = () => {
    // Reset the log directory
    rmSync('./log', { recursive: true, force: true });
    mkdirSync('./log');

    // Load the args
    const args = getArgs();

    // Configure Factory
    const factoryProps = new solace.SolclientFactoryProperties();
    factoryProps.profile = solace.SolclientFactoryProfiles.version10;
    solace.SolclientFactory.init(factoryProps);

    // Get the session
    const { session, shutdown } = buildSession(args);

    process.once("SIGINT", () => shutdown("SIGINT"));
    process.once("SIGTERM", () => shutdown("SIGTERM"));

    // Connect
    session.connect();
};

main();

import solace from 'solclientjs';
import commandLineArgs from 'command-line-args';
import Meter from './meter.js';
import { mkdirSync, writeFileSync, appendFileSync, rmSync } from 'node:fs';

/**
 * @typedef {'none'|'console'|'file'|'directory'} OutputType
 * @typedef {{
 *  username: string,
 *  password: string,
 *  host: string,
 *  vpn: string,
 *  queue: string,
 *  output: OutputType
 * }} Arguments
 * */
const getArgs = () => {
    /** @type {Arguments} */
    const args = commandLineArgs([
        { name: 'username', alias: 'u', type: String, defaultValue: process.env.JUMP_USER },
        { name: 'password', alias: 'p', type: String, defaultValue: process.env.JUMP_PASS },
        { name: 'host', alias: 'h', type: String, defaultValue: process.env.JUMP_HOST },
        { name: 'vpn', alias: 'v', type: String, defaultValue: process.env.JUMP_VPN },
        { name: 'queue', alias: 'q', type: String, defaultValue: process.env.JUMP_QUEUE },
        { name: 'output', alias: 'o', type: String, defaultValue: process.env.JUMP_OUTPUT || 'none' },
    ]);

    // Validate args
    if (!args.username || !args.password || !args.host || !args.vpn || !args.queue)
        throw new Error('please provide all required arguments via CLI or environment variables');
    const outputTypes = ['none', 'console', 'file', 'directory'];
    if (!outputTypes.includes(args.output))
        throw new Error('output type must be in ' + JSON.stringify(outputTypes));

    return args;
};

/**
 * Creates a session from the provided arguments
 * @param {Arguments} args 
 * @returns {solace.Session} the session
 */
const buildSession = (args) => {
    const session = solace.SolclientFactory.createSession({
        url: args.host,
        vpnName: args.vpn,
        userName: args.username,
        password: args.password,
    });

    // Session event handlers
    let messageCount = 0;
    const meter = new Meter();
    session.on(solace.SessionEventCode.UP_NOTICE, () => {
        console.log("Connected.");

        const queue = solace.SolclientFactory.createDurableQueueDestination(args.queue);

        const consumer = session.createMessageConsumer({
            queueDescriptor: {
                name: queue.getName(),
                type: solace.QueueType.QUEUE
            },
            acknowledgeMode: solace.MessageConsumerAcknowledgeMode.CLIENT
        });

        if (args.output !== 'console') {
            setInterval(() => console.log(meter.getRates()), 1000);
        }

        consumer.on(solace.MessageConsumerEventName.UP, () => {
            console.log(`Bound to queue`);
        });

        consumer.on(solace.MessageConsumerEventName.CONNECT_FAILED_ERROR, (e) => {
            console.error("Consumer failed:", e);
        });

        consumer.on(solace.MessageConsumerEventName.DOWN, () => {
            console.log("Consumer disconnected");
        });

        consumer.on(solace.MessageConsumerEventName.MESSAGE, (message) => {
            try {
                meter.mark();
                const xmlDecoded = message.getXmlContentDecoded();
                const messageId = message.getApplicationMessageId();
                const destination = message.getDestination()?.getName();
                messageCount++
                if (xmlDecoded) {
                    switch (args.output) {
                        case 'none': {
                            console.log(`[${messageCount}] Received [${destination}] with size: ${xmlDecoded.length}`);
                            break;
                        }
                        case 'console': {
                            console.log(xmlDecoded);
                            break;
                        }
                        case 'directory': {
                            const path = `./log/${messageCount}.xml`;
                            writeFileSync(path, xmlDecoded);
                            console.log(`[${messageCount}] Wrote to ${path}`);
                            break;
                        }
                        case 'file': {
                            const path = `./log/messages.log`;
                            appendFileSync(path, xmlDecoded + '\n');
                            console.log(`[${messageCount}] Appended to ${path}`);
                            break;
                        }
                        default: throw new Error('unrecognized output type: ' + args.output);
                    }
                }

                // Tell the broker we're done with the message
                message.acknowledge();
            } catch (err) {
                console.error(err);
            }
        });

        consumer.connect();
    });

    session.on(solace.SessionEventCode.CONNECT_FAILED_ERROR, (e) => {
        console.error("Connection failed:", e);
    });

    session.on(solace.SessionEventCode.DISCONNECTED, () => {
        console.log("Disconnected");
    });

    // Ensure clean shutdown
    process.on("SIGINT", () => {
        console.log("Disconnecting...");
        try {
            session.disconnect();
        } catch (_) {}

        process.exit(0);
    });

    return session;
};

const main = () => {
    // Reset the log directory
    rmSync('./log', { recursive: true, force: true });
    mkdirSync('./log');

    // Load the args
    const args = getArgs();

    // Configure Factory
    const factoryProps = new solace.SolclientFactoryProperties();
    factoryProps.profile = solace.SolclientFactoryProfiles.version10;
    solace.SolclientFactory.init(factoryProps);

    // Get the session
    const session = buildSession(args);

    // Connect
    session.connect();
};

main();
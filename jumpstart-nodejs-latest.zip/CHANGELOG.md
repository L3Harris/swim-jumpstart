# JumpStart JS Changelog

## 1.1.0

- switch from npm to pnpm

## 1.0.0

- Initial Release

class EWMA {
  constructor(intervalMs) {
    this.intervalMs = intervalMs;
    this.intervalRate = 0;
    this.count = 0;
    this.initialized = false;
  }

  update(n) {
    this.count += n;
  }

  tick() {
    const instantRate =
      (this.count / this.intervalMs) * 1000;

    this.count = 0;

    // 1 - exp(-5 / window)
    // This gives the standard EWMA smoothing factor used
    // by Dropwizard Metrics.
    const alpha = 1 - Math.exp(-this.intervalMs / this.windowMs);

    if (this.initialized) {
      this.intervalRate +=
        alpha * (instantRate - this.intervalRate);
    } else {
      this.intervalRate = instantRate;
      this.initialized = true;
    }
  }

  ratePerSecond() {
    return this.intervalRate;
  }
}

class Meter {
  constructor() {
    this.count = 0;
    this.startTime = process.hrtime.bigint();

    // Dropwizard's standard meter tick is 5 seconds.
    this.tickIntervalMs = 5000;

    this.m1 = new EWMA(this.tickIntervalMs);
    this.m5 = new EWMA(this.tickIntervalMs);
    this.m15 = new EWMA(this.tickIntervalMs);

    // EWMA decay windows.
    this.m1.windowMs = 60_000;
    this.m5.windowMs = 5 * 60_000;
    this.m15.windowMs = 15 * 60_000;

    this.timer = setInterval(() => {
      this.m1.tick();
      this.m5.tick();
      this.m15.tick();
    }, this.tickIntervalMs);

    // Don't keep Node alive just because the meter exists.
    this.timer.unref?.();
  }

  mark(n = 1) {
    if (n < 0) {
      throw new RangeError("n must be >= 0");
    }

    this.count += n;

    this.m1.update(n);
    this.m5.update(n);
    this.m15.update(n);
  }

  getCount() {
    return this.count;
  }

  getMeanRate() {
    const elapsedNs = process.hrtime.bigint() - this.startTime;
    const elapsedSeconds = Number(elapsedNs) / 1e9;

    if (elapsedSeconds === 0) {
      return 0;
    }

    return this.count / elapsedSeconds;
  }

  getOneMinuteRate() {
    return this.m1.ratePerSecond();
  }

  getFiveMinuteRate() {
    return this.m5.ratePerSecond();
  }

  getFifteenMinuteRate() {
    return this.m15.ratePerSecond();
  }

  getRates() {
    return {
      count: this.getCount(),
      meanRate: this.getMeanRate(),
      oneMinuteRate: this.getOneMinuteRate(),
      fiveMinuteRate: this.getFiveMinuteRate(),
      fifteenMinuteRate: this.getFifteenMinuteRate()
    };
  }

  stop() {
    clearInterval(this.timer);
  }
}
export default Meter;

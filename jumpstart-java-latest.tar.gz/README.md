# Consumer JumpStart

This is a simple JMS Consumer that allows for testing the connection to SCDS.
It is not intended to be used for a real world application.
The JumpStart allows you to log the message rate metrics and/or messages to the console.

## Configuration Options

The following configuration options will be provided when you create a subscription:

| Option | Description | Default |
| :----- | :---------- | :------ |
| `providerUrl` | url of the message broker including the port (e.g. tcps://hostname:55443) | - |
| `queue` | the name of the queue to connect to receive data | - |
| `connectionFactory` | the connection factory used for connecting which contains specific configuration parameters defined by an administrator | - |
| `username` | the connection username for authentication | - |
| `password` | the connection password for authentication | - |
| `vpn` | the message vpn to connect to on the broker | - |
| `metrics` | log message rate metrics to the console. Set it to `false` for disabling metrics. | `true` |
| `output` | log messages to a specific output. See below for options. | `com.harris.cinnato.outputs.NoopOutput` |
| `headers` | includes message property values in the header. Set it to `true` for including headers. | `false` |

### Output Types

#### Built-in Output Types

- **com.harris.cinnato.outputs.NoopOutput**: does not output message
- **com.harris.cinnato.outputs.StdoutOutput**: outputs the messages to standard out
- **com.harris.cinnato.outputs.FileOutput**: outputs the messages to a single rotating file log located in `./log/messages.log`
- **com.harris.cinnato.outputs.MessageFileOutput**: outputs each message to a separate file located in `./log/`

#### Custom Output Type

Extend the `com.harris.cinnato.outputs.Output` class and implement a `output(String message)` function.  When launching the JumpStart kit pass in new class `-Doutput=com.harris.cinnato.outputs.<NewClass>`

## Execution

### Running with CLI options

```bash
# Bash for Linux
./bin/run \
-DproviderUrl=CHANGEME_URL \
-Dqueue=CHANGEME_QUEUE \
-DconnectionFactory=CHANGEME_FACTORY \
-Dusername=CHANGEME_USER \
-Dpassword=CHANGEME_PASS \
-Dvpn=CHANGME_VPN
```

```ps1
# Powershell for Windows
bin\run.bat `
-DproviderUrl=CHANGEME_URL `
-Dqueue=CHANGEME_QUEUE `
-DconnectionFactory=CHANGEME_FACTORY `
-Dusername=CHANGEME_USER `
-Dpassword=CHANGEME_PASS `
-Dvpn=CHANGME_VPN
```

### Running with config file

You can also run the Java jumpstart kit with a config file (`application.conf`).

```conf
providerUrl:CHANGEME_URL
queue:CHANGEME_QUEUE
connectionFactory:CHANGEME_FACTORY
username:CHANGEME_USER
password:CHANGEME_PASS
vpn:CHANGME_VPN
metrics:false
output:com.harris.cinnato.outputs.FileOutput
json:true
```

```bash
# Bash for Linux
./bin/run -Dconfig.file=path/to/config-file
```

```cmd
REM Command Prompt for Windows
bin\run.bat  -Dconfig.file=path/to/config-file
```

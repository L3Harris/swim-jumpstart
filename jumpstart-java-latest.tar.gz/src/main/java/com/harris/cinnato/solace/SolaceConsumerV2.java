/*
 * Copyright (c) 2021 L3Harris Technologies
 */
package com.harris.cinnato.solace;

import java.util.Enumeration;

import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.codahale.metrics.Meter;
import com.codahale.metrics.MetricRegistry;
import com.harris.cinnato.outputs.Output;
import com.typesafe.config.Config;

import jakarta.jms.BytesMessage;
import jakarta.jms.Connection;
import jakarta.jms.ExceptionListener;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageListener;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;

public abstract class SolaceConsumerV2 implements MessageListener, ExceptionListener {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    final Config config;

    private Connection connection;
    private final String connectionName;
    private final Meter messageRate;
    private final Output reporter;

    private final int RETRY_INTERVAL_SECONDS = 15;
    private final int MAX_RETRY_WINDOW_SECONDS = 3600;

    /**
     * Constructor sets configuration items
     * @param config the consumer config properties
     */
    SolaceConsumerV2(Config config, MetricRegistry metrics, Output reporter) throws NamingException {
        this.messageRate = metrics.meter("messages");
        this.config = config;
        this.reporter = reporter;
        this.connectionName = "[ " + config.getString("providerUrl") + " -- " + config.getString("queue") + " ]";
    }

    protected abstract Connection getConnection () throws Exception;

    protected abstract Queue getQueue (Session session) throws Exception;

    /**
     * Opens a connection and creates a message consumer for receiving messages
     */
    public void connect() throws Exception {
        boolean success = false;
        int attempts = 0;
        while (!success && attempts < (MAX_RETRY_WINDOW_SECONDS / RETRY_INTERVAL_SECONDS)) {
            try {
                this.connection = this.getConnection();
                success = true;
            } catch (Exception e) {
                if (e instanceof org.apache.qpid.jms.exceptions.JmsConnectionFailedException || e instanceof org.apache.qpid.jms.JmsConnectionRemotelyClosedException || e.toString().contains("Connection reset by peer") || e.toString().contains("Connection refused") || e.toString().contains("connection timed out")) {
                    this.logger.warn("New connection failed. Retrying...");
                    attempts++;
                    try {
                        Thread.sleep(RETRY_INTERVAL_SECONDS * 1000);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException(ie);
                    }
                } else {
                    throw e;
                }
            }
        }
        try {

            this.connection.setExceptionListener(this);
            Session session = this.connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Queue theQueue = this.getQueue(session);
            MessageConsumer consumer = session.createConsumer(theQueue);
            consumer.setMessageListener(this);
            this.start();
        } catch (Exception e) {
            this.logger.error("Failed to create the connection: " + this.connectionName, e);
            throw e;
        }
    }

    /**
     * Start receiving messages
     */
    private synchronized void start() throws Exception {
        try {
            this.connection.start();
        } catch (Exception e) {
            this.logger.error("Failed to start the connection: " + this.connectionName, e);
            throw e;
        }
    }

    /**
     * Sends received message to the broker. Includes original JMS properties in addition to the message body.
     * @param message The incoming message.
     */
    @Override
    public void onMessage(Message message) {
        try {
            String headers = "";
            String propName;
            Enumeration<?> propertyNames = message.getPropertyNames();
            while (propertyNames.hasMoreElements()) {
                propName = (String) propertyNames.nextElement();
                headers += "Property name = " + propName + "; value = " + message.getStringProperty(propName) + "\n";
            }
            if (message instanceof BytesMessage) {
                BytesMessage byteMessage = (BytesMessage) message;
                byte[] content = new byte[(int) byteMessage.getBodyLength()];
                byteMessage.readBytes(content);
                this.reporter.output(new String(content), headers);
            } else if (message instanceof TextMessage) {
                this.reporter.output(((TextMessage) message).getText(), headers);
            } else {
                this.logger.error("Received incorrect message type");
            }
            this.messageRate.mark();
        } catch (Exception e) {
            this.logger.error("Error receiving message", e);
        }
    }

    @Override
    public void onException(JMSException e) {
        // Catching some specific exceptions that we want to retry on.
        if (e instanceof org.apache.qpid.jms.exceptions.JmsConnectionFailedException || e instanceof org.apache.qpid.jms.JmsConnectionRemotelyClosedException || e.toString().contains("Connection reset by peer") || e.toString().contains("Connection refused") || e.toString().contains("Connection timed out")) {
            this.logger.warn("Existing connection failed. Retrying.");
            try {
                Thread.sleep(10000);
                this.connect();
            } catch (Exception e1) {
                this.logger.error("Exception during connection attempt: ", e1);
            }
        } else {
            this.logger.error("Consumer Exception", e);
            System.exit(-1);
        }
    }
}
